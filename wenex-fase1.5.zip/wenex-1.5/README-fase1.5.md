# Wenex Fase 1.5 — Responsive Polish

Estos 7 archivos sustituyen sus equivalentes en tu proyecto Wenex.

## Cambios incluidos

1. **`src/app/layout.tsx`** — Nuevo: viewport mobile-first, themeColor, soporte iOS standalone, safe-area cover
2. **`src/app/globals.css`** — Nuevo: variables safe-area, tap highlight off, scrollbar móvil oculta, prefers-reduced-motion
3. **`src/components/layout/Header.tsx`** — Nuevo: header compacto en móvil con buscador colapsable a pantalla completa
4. **`src/components/layout/Sidebar.tsx`** — Nuevo: drawer overlay con backdrop en móvil, sidebar fijo en desktop, cierre con Escape
5. **`src/components/layout/AppShell.tsx`** — Nuevo: lógica que detecta móvil vs desktop y mantiene estado correcto
6. **`src/components/skills/SkillCard.tsx`** — Nuevo: tipografía 15px en móvil para mejor lectura, sizes optimizados
7. **`src/components/skills/CategoryChips.tsx`** — Nuevo: padding mobile reducido, role="tablist" para accesibilidad

## Cómo aplicarlo

Hay dos formas, elige la que prefieras.

### Opción A — Reemplazar archivos manualmente

1. Descomprime el zip
2. Copia los 7 archivos sobre los del proyecto Wenex (sobrescribir cuando pregunte)
3. Sigue los pasos de "Verificación" abajo

### Opción B — Comandos terminal

Desde dentro de la carpeta `~/Escritorio/wenex/`:

```
unzip -o ~/Descargas/wenex-fase1.5.zip
cp -r wenex-1.5/src/* src/
rm -rf wenex-1.5
```

## Verificación local

Antes de subir a GitHub:

```
# 1) Asegúrate de que el dev server está parado (Ctrl+C en su terminal)

# 2) Verifica que el build pasa
npm run build

# 3) Si pasa, arranca dev y prueba
npm run dev
```

Abre `http://localhost:3001` (o el puerto que diga) y prueba:

- En tu navegador, abre las **DevTools** (F12) y activa el **modo dispositivo móvil** (Ctrl+Shift+M en Firefox/Chrome)
- Selecciona un perfil de iPhone SE (375×667) o Pixel 7
- Verifica:
  - El sidebar lateral está oculto inicialmente
  - Pulsa el icono ☰ → se abre como overlay con fondo oscuro detrás
  - Pulsa fuera del sidebar o la X → se cierra
  - Pulsa una categoría → cierra el drawer y filtra el feed
  - Pulsa el icono lupa 🔍 arriba → se abre el buscador a pantalla completa
  - Escribe "Granada" y pulsa Enter → busca y cierra el buscador
  - Las tarjetas se ven en una sola columna, legibles
  - Los chips de categoría se desplazan horizontalmente con el dedo

- Cambia el viewport a un iPad (768×1024):
  - Sidebar fijo de 60px (solo iconos)
  - Pulsa ☰ → se expande a 240px con texto
  - Tarjetas en 2 columnas

- Cambia a desktop (1440×900):
  - Sidebar fijo expandido
  - Buscador inline en la cabecera
  - 3-4 columnas de tarjetas

## Subir a producción

Si todo lo anterior funciona:

```
git add .
git commit -m "Fase 1.5: responsive mobile-first"
git push
```

Vercel re-despliega automáticamente en 2-3 minutos.

## Test final en móvil real

Cuando Vercel termine, abre `https://wenex-sigma.vercel.app` en tu móvil real y verifica:

- El header no se aprieta
- El sidebar abre y cierra suave
- El buscador es cómodo de usar
- Los chips se desplazan
- Las tarjetas se ven bonitas
- Los botones se pueden pulsar sin precisión quirúrgica
